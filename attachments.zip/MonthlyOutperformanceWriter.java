package com.fund;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author milan
 * 
 */
public class MonthlyOutperformanceWriter {
	
	//Delimiter used in CSV file
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	
	//CSV file header
	private static final String FILE_HEADER = "fundName,date,excess,outperformance,return,rank";

	public static void writeCsvFile(String fileName) {
		

		
		FileWriter fileWriter = null;
				
		try {
			fileWriter = new FileWriter(fileName);

			//Write the CSV file header
			fileWriter.append(FILE_HEADER.toString());
			
			//Add a new line separator after the header
			fileWriter.append(NEW_LINE_SEPARATOR);
			
			//Write a new  object list to the CSV file
			for (FundPojo fund : funds) {
				fileWriter.append(String.valueOf(fund.getFundName()));
				fileWriter.append(COMMA_DELIMITER);
			}
			for (BenchReturnSeriesPojo benchReturnSerie : benchReturnSeries && FundReturnSeriesPojo fundReturnSerie : fundReturnSeries) {
				fileWriter.append(String.valueOf(benchReturnSerie.getDate()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(fundReturnSerie.getReturn() - benchReturnSerie.getReturn()));
				fileWriter.append(COMMA_DELIMITER);
				if((fundReturnSerie.getReturn() - benchReturnSerie.getReturn())>1){
				fileWriter.append(String.valueOf("underperformed");
				}
				else if ((fundReturnSerie.getReturn() - benchReturnSerie.getReturn())<-1){
				fileWriter.append(String.valueOf("outperformed");
				}
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(fundReturnSerie.getReturn()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(fundReturnSerie.getRank()));
				fileWriter.append(COMMA_DELIMITER);
	
			}


			System.out.println("CSV file was created successfully !!!");
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		} finally {
			
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
			}
			
		}
	}
}
