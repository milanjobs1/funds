package com.fund;

/**
 * @author milan
 *
 */
public class FundPojo {
	
	private String fundCode;
	private String fundName;
	private String benchmarkCode;
	
	/**
	 * @param fundCode
	 * @param fundName
	 * @param benchmarkCode
	 */
	public FundPojo(String fundCode, String fundName, String benchmarkCode) {
		super();
		this.fundCode = fundCode;
		this.fundName = fundName;
		this.benchmarkCode = benchmarkCode;
	}


	/**
	 * @return the fundCode
	 */
	public String getFundCode() {
		return fundCode;
	}
	/**
	 * @param fundCode the fundCode to set
	 */
	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}
	/**
	 * @return the fundName
	 */
	public String getFundName() {
		return fundName;
	}
	/**
	 * @param fundName the fundName to set
	 */
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	/**
	 * @return the benchmarkCode
	 */
	public String getBenchmarkCode() {
		return benchmarkCode;
	}
	/**
	 * @param benchmarkCode the benchmarkCode to set
	 */
	public void setBenchmarkCode(String benchmarkCode) {
		this.benchmarkCode = benchmarkCode;
	}

	
	@Override
	public String toString() {
		return "FundPojo [fundCode=" + fundCode
				+ ", fundName=" + fundName + ",  benchmarkCode="
				+ benchmarkCode + "]";
	}
}
