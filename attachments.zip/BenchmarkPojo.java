package com.fund;

/**
 * @author milan
 *
 */
public class BenchmarkPojo {
	
	private String benchmarkCode;
	private String benchmarkName;

	
	/**
	 * @param benchmarkCode
	 * @param benchmarkName
	 */
	public BenchmarkPojo(String benchmarkCode, String benchmarkName) {
		super();
		this.benchmarkCode = benchmarkCode;
		this.benchmarkName = benchmarkName;
	}



	/**
	 * @return the benchmarkCode
	 */
	public String getBenchmarkCode() {
		return benchmarkCode;
	}
	/**
	 * @param benchmarkCode  the benchmarkCode to set
	 */
	public void setBenchmarkCode(String benchmarkCode) {
		this.benchmarkCode = benchmarkCode;
	}

	/**
	 * @return the benchmarkName
	 */
	public String getBenchmarkName() {
		return benchmarkName;
	}
	/**
	 * @param benchmarkName the benchmarkName to set
	 */
	public void setBenchmarkName(String benchmarkName) {
		this.benchmarkName = benchmarkName;
	}
	
	@Override
	public String toString() {
		return "BenchmarkPojo [benchmarkCode=" + benchmarkCode
			 + ",  benchmarkName="+ benchmarkName + "]";
	}
}
