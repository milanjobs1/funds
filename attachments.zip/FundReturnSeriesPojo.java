package com.fund;

/**
 * @author milan
 *
 */
public class FundReturnSeriesPojo {
	
	private String code;
	private Date date;
        private double return;

	
	/**
	 * @param code
	 * @param date
	 * @param return
	 */
	public FundReturnSeriesPojo(String code, Date date, double return) {
		super();
		this.code = code;
		this.date = date;
		this.return = return;
	}



	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the Code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}


	/**
	 * @return the return
	 */
	public double getReturn() {
		return return;
	}
	/**
	 * @param return the return to set
	 */
	public void setReturn(double return) {
		this.return = return;
	}
	
	@Override
	public String toString() {
		return "FundReturnSeriesPojo [code=" + code
			 + ",  date="+ date + " + ",  return="+ return + "]";
	}
}
