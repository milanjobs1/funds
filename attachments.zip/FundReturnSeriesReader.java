package com.fund;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author milan
 *
 */
public class FundReturnSeriesReader {
	
	//Delimiter used in CSV file
	private static final String COMMA_DELIMITER = ",";
	
	//Student attributes index

	private static final int CODE_IDX = 1;
	private static final int DATE_IDX = 2;
	private static final int RETURN_IDX = 3; 

	
	public static void readCsvFile(String fileName) {

		BufferedReader fileReader = null;
     
        try {
        	
        	//Create a new list of FundReturnSeries to be filled by CSV file data 
        	List fundReturnSeries = new ArrayList();
        	
            String line = "";
            
            //Create the file reader
            fileReader = new BufferedReader(new FileReader(fileName));
            
            //Read the CSV file header to skip it
            fileReader.readLine();
            
            //Read the file line by line starting from the second line
            while ((line = fileReader.readLine()) != null) {
                //Get all tokens available in line
                String[] tokens = line.split(COMMA_DELIMITER);
                if (tokens.length > 0) {
                	//Create a new fund object and fill his  data
					FundReturnSeriesPojo fundReturnSerie = new FundReturnSeriesPojo(tokens[CODE_IDX], tokens[DATE_IDX],tokens[RETURN_IDX]);
					fundReturnSeries.add(fundReturnSerie);
				}
            }
            
            //Print the new FundReturnSeriesPojo list
            for (FundReturnSeriesPojo fundReturnSerie : fundReturnSeries) {
				System.out.println(fundReturnSerie.toString());
			}
        } 
        catch (Exception e) {
        	System.out.println("Error in CsvFileReader !!!");
            e.printStackTrace();
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {
            	System.out.println("Error while closing fileReader !!!");
                e.printStackTrace();
            }
        }

	}

}
