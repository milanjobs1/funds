package com.fund;

/**
 * @author milan
 *
 */
public class FinalReadWriteTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String fileName1 = System.getProperty("user.home")+"/Fund.csv";

		System.out.println("\nRead Fund CSV file:");
		FundReader.readCsvFile(fileName1);

		String fileName2 = System.getProperty("user.home")+"/Benchmark.csv";

		System.out.println("\nRead Benchmark CSV file:");
		BenchmarkReader.readCsvFile(fileName2);

		String fileName3 = System.getProperty("user.home")+"/fundReturnSeries.csv";

		System.out.println("\nRead fundReturnSeries CSV file:");
		FundReturnSeriesReader.readCsvFile(fileName3);

		String fileName4 = System.getProperty("user.home")+"/benchReturnSeries.csv.csv";

		System.out.println("\nRead benchReturnSeries CSV file:");
		BenchReturnSeriesReader.readCsvFile(fileName4);


		String fileName5 = System.getProperty("user.home")+"/monthlyOutperformance.csv";

		System.out.println("Write monthlyOutperformance CSV file:");
		MonthlyOutperformanceWriter.writeCsvFile(fileName5);
		


	}

}
